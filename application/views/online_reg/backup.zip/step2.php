<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<?php 
function check_registered($id, $user_regs)
{
foreach($user_regs as $k => $v)
{
if($v["event"] == $id)
{
return $v;
}
}
return false;
}
if($rows==0)
{
?>
<p>We couldn't recognize you! Please make sure you have entered a valid URL.</p>
<?php } else { if($error) { ?>		
<style>
.button {
	-moz-box-shadow:inset 0px 1px 0px 0px #f5978e;
	-webkit-box-shadow:inset 0px 1px 0px 0px #f5978e;
	box-shadow:inset 0px 1px 0px 0px #f5978e;
	background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #f24537), color-stop(1, #c62d1f) );
	background:-moz-linear-gradient( center top, #f24537 5%, #c62d1f 100% );
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#f24537', endColorstr='#c62d1f');
	background-color:#f24537;
	-webkit-border-top-left-radius:6px;
	-moz-border-radius-topleft:6px;
	border-top-left-radius:6px;
	-webkit-border-top-right-radius:6px;
	-moz-border-radius-topright:6px;
	border-top-right-radius:6px;
	-webkit-border-bottom-right-radius:6px;
	-moz-border-radius-bottomright:6px;
	border-bottom-right-radius:6px;
	-webkit-border-bottom-left-radius:6px;
	-moz-border-radius-bottomleft:6px;
	border-bottom-left-radius:6px;
	text-indent:0;
	border:1px solid #d02718;
	display:inline-block;
	color:#ffffff;
	font-family:Arial;
	font-size:15px;
	font-weight:bold;
	font-style:normal;
	padding: 10px;
	text-decoration:none;
	text-align:center;
	text-shadow:1px 1px 0px #810e05;
}
.button:hover {
	background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #c62d1f), color-stop(1, #f24537) );
	background:-moz-linear-gradient( center top, #c62d1f 5%, #f24537 100% );
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#c62d1f', endColorstr='#f24537');
	background-color:#c62d1f;
}.button:active {
	position:relative;
	top:1px;
}

#submit {
    padding: 8px;
    font-size: 20px;
    font-weight: normal;
    width: 100px;
    border-radius: 11px;
    border: none;
    background: rgb(167, 58, 58);
    color: whitesmoke;
    box-shadow: 0 0 10px rgb(0, 0, 0);
}
h1 {
    font-family: verdana,sans-serif;
    font-weight: normal;
    color: rgb(255, 187, 187);
}
.panel-container span {
    display: block;
    height: 30px;
}
.tab.active a {
    color: white;
    font-weight: bold;
}
input[type="checkbox"] {
    zoom: 2;
}
label {}
.panel-container label {
    position: relative;
    top: 9px;
}
.etabs {
margin: 0;
padding: 0;
display: inline-block;
width: 300px;
}
.tab.active {
padding-top: 6px;
position: relative;
top: 1px;
border-color: rgb(102, 102, 102);
font-weight: bold;
}
.tab {
display: inline-block;
zoom: 1;
border: none;
width: 100%;
}
.tab a.active {
font-weight: bold;
}

.tab a {
font-size: 1.1em;
color: rgb(255, 187, 187);
line-height: 2em;
font-family: tahoma,verdana,sans-serif;
display: block;
font-weight: normal;
padding: 0 10px;
outline: none;
text-decoration: none;
}

.tab a:hover {
text-decoration:underline;
}

.tab-container .panel-container {
vertical-align: top;
display: inline-block;
height: 300px;
background: rgba(0, 0, 0, 0);
padding: 10px;
}
.hide{
display:none;
}

.info-box{
width: 700px;
padding: 5px;
border bottom: dashed rgb(155, 54, 54) 1px;
}
ul {
list-style: none;
color: rgb(255, 255, 255);
font-family: sans-serif;
}
.info-box p {
color: rgb(255, 178, 181);
font-weight: bold;
font-family: verdana, sans-serif;
}
</style>
<link href="<?php echo base_url(); ?>css/form.css?v=1.1" rel="stylesheet">
<div id="page" style="background:#C73F57;">
<div class="info-box">
<p><?php if($param_key==''){echo 'Hi ';} else { echo 'Welcome back ';} echo $usd[0]["name"];?>, here are the details you have registered with us :- </p>
<ul>
<li>Email : <?php echo $usd[0]["email"];?></li>
<li>College : <?php echo $usd[0]["college"];?></li>
<li>Department : <?php echo $usd[0]["dept"];?></li>
<li>Contact number : <?php echo $usd[0]["cno"];?></li>
</ul>
<p>Now you may select the events to enroll for.</p>
</div>
<h1>Events</h1>
<?php echo validation_errors();
echo form_open(base_url().uri_string(),array('id'=>'reg-form'));
$tab_heads = array();
$tab_bodies = array();
$i=0;
foreach($egroups as $k => $v)
{
$tab_heads[] = $v["name"];
$tab_bodies[$i] = "";
foreach($v["events"] as $k => $v)
{
$ch = false;
if(check_registered($v->event_id, $user_regs))
{
$ch = true;
}
$data = array(
    'name'        => "events[]",
    'id'          => $v->event_name,
    'value'       => $v->event_id,
    'checked'     => $ch
    );
$tab_bodies[$i] .= '<span>'. form_checkbox($data).form_label($v->event_name, $v->event_name).'</span>';
}
$i++;
}
?>

<div id="tab-container" class="tab-container">
  <ul class="etabs">
  <?php for($i=0; $i<count($tab_heads); $i++) { ?>
    <li class="tab <?php if($i==0) echo 'active';?>"><a targ="#tabc<?php echo $i; ?>" id="tab<?php echo $i; ?>"><?php echo $tab_heads[$i]; ?></a></li>
	<?php } ?>
  </ul>
  
  <div class="panel-container">
   <?php for($i=0; $i<count($tab_bodies); $i++) { ?>
  <div id="tabc<?php echo $i; ?>" class="<?php if($i!=0) echo 'hide';?>">
  <?php echo $tab_bodies[$i]; ?>
  </div>
  <?php } ?>
  </div>
</div>

<div>
<input type="submit" name="submit" class="button">
</div>
</form>
<script>
var th = $("#tab-container ul li");
var i=0;
th.each(function() {
$("#"+$(this).children().attr("id")).click(function(){
var cur = $(this);
if(!cur.parent().hasClass('active'))
{
$(".etabs li").removeClass("active");
cur.parent().addClass("active");
$(".panel-container div").hide();
$(cur.attr("targ")).show();
}

});
});
</script>

</div>
<?php
}
else
{
?>
<div id="page" style="background:#C73F57;">
<p style="font-family: verdana,sans-serif;
    color: white;
    line-height: 2em;
    font-size: 1.3em;
">Please check your mailbox for confirmation and account details. <br><sub><b>PS</b>. Remember to check your <b>Junk</b> folder as well </sub><br>
Like our<a href="https://www.facebook.com/bodhiofficial" target="_blank" style="
    text-decoration: none;
    color: rgb(76, 102, 164);
    text-shadow: 0 0 10px rgb(83, 30, 30);
"> facebook page </a>for getting regular updates
</p>
</div>
<?php
} }