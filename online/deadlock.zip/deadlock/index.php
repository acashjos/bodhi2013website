<?php
	
/* 	Author : 		Sony Mathew aka ynos1234
	Description : 	Online user registration handling script.
*/	
include_once('./library/db_common.php');

#sanitising post and get array variables so that mysql gets a clean data
  	array_walk_recursive($_POST, 'sanitizeVariables'); 
  	array_walk_recursive($_GET, 'sanitizeVariables'); 


#basic files to be included for database connection and other processing
	
	include_once('./library/general.php');
	include_once('./library/login.php');

	
#logging every user
	$link = connect();
	$sql = 'update counter set total_hits = total_hits+1';
	$result = mysql_query($sql);
	check($result);

	$bd = '' ;


    if (isset($_GET['q'])) 
    		{      
					include_once('./library/tk13id.php');  
					//validating a login
					if ($_GET['q'] == 'login') 				
						{	
							$bd = login() ;
						}	   	   

					//processing the pre-register form
					elseif ( $_GET['q'] == 'pre_register')	
						{						
							include_once('./library/pre_reg_form_process.php');
							$bd = pre_reg() ;
						}

					
					//processing the pre-register form
					elseif ( $_GET['q'] == 'pre_register_form')	
						{						
							include_once('./library/pre_registration_form.php');
							$bd = pre_reg_form() ;
						}	

					//processing the register form after validating email	
					elseif ($_GET['q'] == 'register')		
						{	
							include_once('./library/post_reg.php');
							$bd = register_user() ;					
						}

					//proccessing if any user forgets his password
					elseif ($_GET['q'] == 'forgot_password')
						{		
							include_once('./library/forgot_password.php');
							$bd = forgot_password() ;
						}
					
					//processing the email verification
					elseif ( $_GET['q'] == 'verify_email')	
						{	
							include_once('./library/verify_reg.php');
							$bd = email_verify_reg() ;
						}	

					//processing the email verification
					elseif ( $_GET['q'] == 'resend_mail')	
						{	
							include_once('./library/resend_mail.php');
							$bd = resend() ;
						}		
						

					else 									
						{									}	   
			}
		//after validating the login
    elseif ( isset($_COOKIE['tk13_general'] ) )
			{		
					$ck = explode ('+' , $_COOKIE['tk13_general']) ;
					$bd = authorise() ? $ck[0] : 'Invalid Cookie.'  ;		
			}
						   	   
	else  	{	}	
					   	               
  	echo $bd;

?>