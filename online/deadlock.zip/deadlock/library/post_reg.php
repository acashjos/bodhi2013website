<?php


function register_user( )

    {
    
        $check1 = 0 ;

        $result = mysql_query('select name,username,password,email_verify from user_profiles where email = \''.$_POST['email'].'\'');
        check($result) ;          
        $row = mysql_fetch_row ( $result ) ;

        if(mysql_num_rows($result))
              {
                  $name =  $row[0];
                  $password =  $row[2];
                    

                  //verifyig the email verification string 
                  if ( $_POST['verify'] == $row[3]  )      
                        { $check1 = 1 ; } 
                  else  
                        { 
                            $body = $body .' * Email verification is not correct. <br/>' ; 
                            $check1 = 0 ; 
                        }    


                  //validating email address
                  if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))       
                        { $check1 = 1 ;  } 
                  else                                                          
                        { 
                          $body = ' * Invalid email <br/>' ;
                          $check1 = 0 ; 
                        }

                  //validating phone number
                  if( $check1 )  
                      {  
                          if ( strlen($_POST['phone']) > 9 && strlen($_POST['phone']) < 14 )       
                              {   $check1 = 1 ; } 
                          else                                        
                              { 
                                  $body = $body .' * Your mobile phone should have exactly 10 digits. <br/>' ; 
                                  $check1 = 0 ;
                              }    
                      }
                  //validating date
                  if( $check1 )    
                      {
                          $date_flag = 1 ;
                          $day = trim($_POST['day']);
                          $month = trim($_POST['month']);
                          $year = trim($_POST['year']);
                          if(!($day < 31 && $day > 0 ))
                              { $date_flag = 0 ; }
                          if(!($month < 13 && $month > 0 ))
                              { $date_flag = 0 ; }
                          if(!($year < 2008 && $year > 1960 ))
                              { $date_flag = 0 ; }

                          if(!($date_flag))
                              { $check1 = 0 ;    }  

                          $dob_date = $day.':'.$month.':'.$year ;  
                      }
                  //entering to database
                  if( $check1 )
                          {   
                             
                            $dt = date("Y-m-d h:i:s");
                              
                            // inserting the user details to database 
                            $result = mysql_query('update user_profiles set id=tk13_id,email_verify=\'VERIFIED\',phone=\''.$_POST['phone'].'\',
                              college=\''.(isset($_POST['college'])?$_POST['college'] : 'NULL').'\',
                              course=\''.(isset($_POST['course'])?$_POST['course'] : 'NULL').'\',dob = \''.$dob_date.'\' where
                              email=\''.trim($_POST['email']).'\'');
                            check($result);
                            
                            //updating number of paricipants in the counter table 
                             $result = mysql_query('update counter set total_online_reg = total_online_reg+1'); 
                             check($result)   ;

                             $result = mysql_query('select tk13_id from user_profiles where email=\''.trim($_POST['email']).'\''); 
                             check($result) ;
                             $row = mysql_fetch_row($result);
                             

                             //sending confirmation mail to the user
                            $to = trim($_POST['email']);
                            $subject = "Bodhi 2013 Registration details";
                            $message = 'Dear '.$_POST['name'].', '.
                                        PHP_EOL.PHP_EOL.'You have been succesfully registered for Bodhi 2013 Online Treasure Hunt.'.
                                        PHP_EOL.'Your authentication details are as follows :'.
                                        PHP_EOL.PHP_EOL.'Username : '.$_POST['username'].
                                        PHP_EOL.'Your Bodhi 2013 Treasure hunt ID  : '.tk13id($row[0]).
                                        PHP_EOL.PHP_EOL.'Thank you.'.
                                        PHP_EOL.'Bodhi 2013 Team.'.
                                        PHP_EOL.PHP_EOL.'For more details visit www.bodhiofficial.in or drop a mail to webmaster@bodhiofficial.in.';
                            $from = "webmaster@bodhiofficial.in";
                            $headers = "From:" . $from;
                            mail($to,$subject,$message,$headers);

                            $body =' You have been succesfully registered.
                            '.PHP_EOL.'Please check your mail ( check your spam folder also ) for further details and notifications. 
                            Please add webmaster@bodhiofficial.in as your contact in your mail ID. 
                            <meta http-equiv="refresh" content="2;http://www.bodhiofficial.in" />';
                         }   


                     else 
                     {
                        return $body.'You have not been registered.<meta http-equiv="refresh" content="2;http://techkshetra.in" />';
                     }
              }
         else
              {   
                return $body.'You have not been registered.(Error msg : Your email has not been found in our database)<br/>
                              For any queries contact our experts at support@techkshetra.in .<meta http-equiv="refresh" content="2;http://techkshetra.in" />';
              }            

    return $body;

    }





?>