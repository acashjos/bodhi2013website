<?php
	

function login()
    {
          if(!(isset( $_POST['username']) ))
              {  return default_form(); }               	
          
          $result = mysql_query('select tk13_id from user_profiles where username=\''.trim($_POST['username']).'\'');
          check($result);
   
          if( mysql_num_rows($result) > 0 ) // validating username
               {  
                  $result1 = mysql_query('select tk13_id from user_profiles where username=\''.trim($_POST['username']).'\'
                   and password=\''.base64_encode($_POST['pass'].'ynos1234').'\'');
                  check($result1);

                  if( mysql_num_rows($result1) > 0 ) // validating username and password
                      { 
                          $result2 = mysql_query('select tk13_id from user_profiles where username=\''.trim($_POST['username']).'\'
                          and password=\''.base64_encode($_POST['pass'].'ynos1234').'\' and email_verify=\'VERIFIED\'');
                          check($result2);
                          $row = mysql_fetch_row($result2);  
                          
                          if( mysql_num_rows($result2) > 0 ) // validating username and password and email verification
                            { 
                                $str = random_str(4);
                                //set the cookie and update it in database	    
                                setcookie('tk13_general' , trim($_POST['username']).'+'.$str.'+'.$row[0] , time()+ 4*60*60 ) ;
                                $result = mysql_query('update user_profiles set cookie_key = \''.$str.'\' where tk13_id = '.$row[0] );
                                return 'Hello '.trim($_POST['username']);
                            }
                          else
                            {
                                return 'Sorry, you haven\'t verified yet.Please do verify your email to proceed.' ;
                            }     
                      }
                  else
                      {
                          return 'Sorry, your password seems to be incorrect. Are you YOU?' ;
                      }
                } 
                
          else 
              {  return 'Sorry, you haven\'t registered.' ;  }       
    }
	
function authorize()
                        {
                               $flag = 0;
                               if(substr_count($_COOKIE['tk13_general'], '+') > 0 )
                                   {
                                       $ck = explode ('+' , $_COOKIE['tk13_general']) ;
                                       $flag = 1 ;
                                   }
                               else
                                    {
                                      $ck = $_COOKIE['tk13_general'];
                                    }    
                               $result = mysql_query('select cookie_key from user_profiles where username = '.$ck[1]);
                               check($result) ;
                               $row = mysql_fetch_row($result) ;
                               
                               if ( $row[0] == ($flag? $ck[1] :$ck ) ) // valid user
                                    { return 1; }
                               else 
                                    { 
                                      setcookie('tk13_general' , $_COOKIE['tk13_general'] , time()-60 ) ;  
                                      return 0;
                                    }      
                        }	

function default_form()
                        {
                              return '<form method="post" action="index.php?q=login">
                                      <br/> username   :   <input type="text" name="username" maxlength="20"> <br/>
                                      <br/> Password   :   <input type="password" name="pass" maxlength="15"> <br/>
                                      <br/> <input type="submit" value="Login" /> 
                                      </form>';
                        }
?>