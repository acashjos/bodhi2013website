<?php

/*
Author : 			Sony Mathew aka ynos1234

Description:		This script is used to initialise databases of Techkshetra 2013 website.
					This includes Online registration through the website and also offline registrations.
					Offline registrations include on the spot registration for the registration committe.
					There is also portal event heads to monitor their events and publish the winners.
					Another portal is also provided for certificate committee to issue certificates and mark the status.
*/


include_once('db_common.php');

//connecting to the database
$con = connect();
if (!$con)			{     die(' 1 . Could not connect: ' . mysql_error().'<br/>');        	}
else 				{     print " 1 . connection succesful....!!!! <br/>";        			}


//creating table : 1. user_profiles
$sql = "CREATE TABLE user_profiles
                		(
                            id bigint,
                            tk13_id bigint	AUTO_INCREMENT,
                            primary key (tk13_id),                            
                            username varchar(50) NOT NULL UNIQUE,
                            password varchar(100) NOT NULL,
                            name varchar(50),
                            phone varchar(14),
                            email varchar(250) NOT NULL,
                            college varchar(100),
                            course varchar(50),
                            dob varchar(20),
                            cash int,
                            events_registered_online text,
                            events_registered_offline text,
                            email_verify varchar(10),
                            facebook_key text,
                            cookie_key varchar(18),
                            reg_date datetime
                        )";
if(mysql_query($sql,$con))		{	print " 2 . user_profiles table created.<br/>";              	}
else 							{	print " 2 . user_profiles table could not be created.<br/>".mysql_error().'<br/>'; 	}

#################################################################################################

//creating table : 2. counter
$sql = "CREATE TABLE counter
                		(
                            id smallint NOT NULL AUTO_INCREMENT,
                            primary key (id),                            
                            total_hits bigint,
                            brochure_views int,
                            deadlock_reg int,
                            total_online_reg int,
                            total_offline_reg int,
                            total_cash bigint
                        )";
if(mysql_query($sql,$con))		{	print " 3 . (A) counter table created.<br/>";              	}
else 							{	print " 3 . (A) counter table could not be created.<br/>".mysql_error().'<br/>'; 	}

$sql = 'insert into counter(total_hits,brochure_views,deadlock_reg,total_online_reg,total_offline_reg,total_cash) values(0,0,0,0,0,0)';
if(mysql_query($sql,$con))		{	print " 3 . (B) counter table initialiseed.<br/>";              	}
else 							{	print " 3 . (B) counter table could not be initialised.<br/>".mysql_error().'<br/>'; 	}

###################################################################################################

//creating table : 3. contact
$sql = "CREATE TABLE contact
                		(
                            id smallint NOT NULL AUTO_INCREMENT,
                            primary key (id),
                            name varchar(50),
                            email varchar(250),
                            subject varchar(250),
                            content text
                        )";
if(mysql_query($sql,$con))		{	print " 4 . contact table created.<br/>";              	}
else 							{	print " 4 . contact table could not be created.<br/>".mysql_error().'<br/>'; 	}

###################################################################################################

//creating table : 4. events
$sql = "CREATE TABLE events
                		(
                            id int NOT NULL AUTO_INCREMENT,
                            primary key (id),
                            name varchar(50),
                            description text,
                            rules text,
                            event_heads varchar(200),
                            event_head_emails varchar(255),
                            event_head_phones varchar(30),
                            username varchar(50) NOT NULL UNIQUE,
                            password varchar(30) NOT NULL,
                            venue varchar(200),
                            event_date date,
                            event_time varchar(9),
                            reg_count int,
                            status int,
                            type varchar(12),
                            first varchar(200),
                            second varchar(200),
                            third varchar(200)
                        )";
if(mysql_query($sql,$con))		{	print " 5 . events table created.<br/>";              	}
else 							{	print " 5 . events table could not be created.<br/>".mysql_error().'<br/>'; 	}

###################################################################################################

//creating table : 5. single_event_reg
$sql = "CREATE TABLE single_event_reg
                		(
                            id smallint NOT NULL AUTO_INCREMENT,
                            primary key (id),
                            event_id int,
                            tk13_id bigint,
                            certificate smallint,
                            cash int,
							FOREIGN KEY (tk13_id) REFERENCES user_profiles(tk13_id),
							FOREIGN KEY (event_id) REFERENCES events(id)
                        )";
if(mysql_query($sql,$con))		{	print " 6 . single_event_reg table created.<br/>";              	}
else 							{	print " 6 . single_event_reg table could not be created.<br/>".mysql_error().'<br/>'; 	}

####################################################################################################

//creating table : 6. group_event_reg
$sql = "CREATE TABLE group_event_reg
                		(
                            id smallint NOT NULL AUTO_INCREMENT,
                            primary key (id),
                            event_id int,
                            head_tk13_id bigint,
                            members_tk13_id varchar(200),
                            certificate smallint,
                            cash int,
							FOREIGN KEY (event_id) REFERENCES events(id)
                        )";
if(mysql_query($sql,$con))		{	print " 7 . group_event_reg table created.<br/>";              	}
else 							{	print " 7 . group_event_reg table could not be created.<br/>".mysql_error().'<br/>'; 	}

#####################################################################################################

//creating table : 7. workshop_reg
$sql = "CREATE TABLE workshop_reg
                		(
                            id smallint NOT NULL AUTO_INCREMENT,
                            primary key (id),
                            event_id int,
                            tk13_ids varchar(200),
                            certificate smallint,
                            cash int,
							FOREIGN KEY (event_id) REFERENCES events(id)
                        )";
if(mysql_query($sql,$con))		{	print " 8 . workshop_reg table created.<br/>";              	}
else 							{	print " 8 . workshop_reg table could not be created.<br/>".mysql_error().'<br/>'; 	}

###################################################################################################

//creating table : 8. winners
$sql = "CREATE TABLE winners
                		(
                            id smallint NOT NULL AUTO_INCREMENT,
                            primary key (id),
                            event_id int,
                            first varchar(200),
                            second varchar(200),
                            third varchar(200),
							FOREIGN KEY (event_id) REFERENCES events(id)
                        )";
if(mysql_query($sql,$con))		{	print " 9 . winners table created.<br/>";              	}
else 							{	print " 9 . winners table could not be created.<br/>".mysql_error().'<br/>'; 	}



/*###################################################################################################
***************************************************************************************************
###################################################################################################*/

# DEADLOCK DATABASES

//creating table : 9. deadlock_profile
$sql = "CREATE TABLE deadlock_profile
                		(
                            id smallint NOT NULL AUTO_INCREMENT,
                            primary key (id),
                            username varchar(50) NOT NULL UNIQUE,
                            current_level int,
                            last_level_clearence_time datetime,
                            attempts bigint,
                            each_level_attempts varchar(255),
                            each_level_completion_time text,
                            facebook_key text,
                            csrs_key varchar(8),
                            image_captcha varchar(4),
                            cookie_key varchar(8),
							FOREIGN KEY (username) REFERENCES user_profiles(username)
                        )";
if(mysql_query($sql,$con))		{	print " 10 . deadlock_profile table created.<br/>";              	}
else 							{	print " 10 . deadlock_profile table could not be created.<br/>".mysql_error().'<br/>'; 	}

#####################################################################################################

//creating table : 10. deadlock_counter
$sql = "CREATE TABLE deadlock_counter
                		(
                            id smallint NOT NULL AUTO_INCREMENT,
                            primary key (id),
                            total_users int,
                            total_levels int,
                            total_attempts bigint,
                            total_hits bigint
                        )";
if(mysql_query($sql,$con))		{	print " 11 . (A) deadlock_counter table created.<br/>";              	}
else 							{	print " 11 . (A) deadlock_counter table could not be created.<br/>".mysql_error().'<br/>'; 	}

$sql = 'insert into deadlock_counter(total_users,total_levels,total_attempts,total_hits) values(0,0,0,0)';
if(mysql_query($sql,$con))		{	print " 11 . (B) deadlock_counter table initialised.<br/>";              	}
else 							{	print " 11 . (B) deadlock_counter table could not be initialised.<br/>".mysql_error().'<br/>'; 	}

#####################################################################################################

//creating table : 11. deadlock_levels
$sql = "CREATE TABLE deadlock_levels
                		(
                            id smallint NOT NULL AUTO_INCREMENT,
                            primary key (id),
                            question text,
                            pic_name varchar(100),
                            answer varchar(255),
                            direct_clues text,
                            page_source_clues text,
                            people_count int
                        )";
if(mysql_query($sql,$con))		{	print " 12 . deadlock_levels table created.<br/>";              	}
else 							{	print " 12 . deadlock_levels table could not be created.<br/>".mysql_error().'<br/>'; 	}



?>