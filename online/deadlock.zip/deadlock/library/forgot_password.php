<?php
	

function forgot_password()
    {
                         	
          $result = mysql_query('select tk13_id,username from user_profiles where email = \''.trim($_POST['email']).'\'');
          check($result);
          $row = mysql_fetch_row($result);
   
          if( mysql_num_rows($result) > 0 ) // validating username and password
               {  
                  
                  $str = random_str(10);
                  $str = str_replace(' ', '', $str);
                  $result = mysql_query('update user_profiles set password = \''.base64_encode($str.'ynos1234').'\' where email = \''.trim($_POST['email']).'\'' );

                   //sending confirmation mail to the user
                            $to = trim($_POST['email']);
                            $subject = "Techkshetra 2013 Password Recovery";
                            $message = 'Dear '.$row[2].', '.PHP_EOL.'.'.PHP_EOL.'Your authentication details are as follows: '
                                        .PHP_EOL.'Username : '.$_POST['username'].PHP_EOL.'
                                        Your New Password  : '.$str.PHP_EOL.PHP_EOL.'Thank you.'.PHP_EOL.'Techkshetra 2013 Team.'
                                        .PHP_EOL.PHP_EOL.'For more details visit www.techkshetra.in or drop a mail to support@techkshetra.in.';
                            $from = "admin@techkshetra.in";
                            $headers = "From:" . $from;
                            mail($to,$subject,$message,$headers);
                  return 'Recovery mail sent to '.trim($_POST['email']).'.(Please check the spam folder also).';
                } 
                
          else 
              {  return 'Sorry, we couldn\'t find your email in our database. Please register and continue.' ;  }       
    }
	

?>