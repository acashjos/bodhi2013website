<?php

function resend()
		{
              // inserting the user details to database 
              $result = mysql_query('select username,email_verify from user_profiles where email=\''.$_POST['email'].'\'');
              check($result);
                          
              if( mysql_num_rows($result) > 0 )
		       	{            
		              $row = mysql_fetch_row($result);
		              if( $row[1] != 'VERIFIED' )
		              	{
				              //sending confirmation mail to the user
				              $to = $_POST['email'];
				              $subject = "Bodhi 2013 Account Verification - RE";
				              $message = 'Dear '.$row[0].','.PHP_EOL.PHP_EOL.'You have registered for Bodhi 2k13 Online Treasure Hunt of Viswajyothi College Of Engineering and Technology.'
				              .PHP_EOL.'To continue with your registration , please verify your email by clicking the link given below :'.
				              PHP_EOL.PHP_EOL.'http://www.bodhiofficial.in/online/reg.php?q=verify_email&email='.$_POST['email'].'&username='.$row[0].'&str='.
				              $row[1].PHP_EOL.'(If clicking on the link dosen\'t work, please copy paste the link in any browser and press enter.)'.
				              PHP_EOL.PHP_EOL.'Thank you.'.PHP_EOL.'Bodhi 2013 Team.'.PHP_EOL.PHP_EOL.
				              'For more details visit www.techkshetra.in or drop a mail to webmaster@bodhiofficial.in.';

				              $from = "webmaster@bodhiofficial.in";
				              $headers = "From:" . $from;
				              mail($to,$subject,$message,$headers);

				              $body ='Please verify your email to continue with the registration. Check your spam folder also.';
				        }
				      else
				      	{	$body = 'Your email has already been verified.';	}  
				}
				else
				{
					 $body = 'You haven\'t registered yet.';	
				}
			return $body;	
		}			
?>