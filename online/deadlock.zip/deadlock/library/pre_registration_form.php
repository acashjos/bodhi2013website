<?php

 function pre_reg_form()
 	{
	
		 $rand = random_str('cookie') ;
		 $verify = explode(',', $rand) ;
		 $en = base64_encode( $verify[0] ) ;
		 setcookie('tk13_verify', $en , time() + 10*60 ) ;
		 create_image( $verify[1] ) ;
   		 exit;			
 	}
 


?>