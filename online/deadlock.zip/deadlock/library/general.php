<?php



function random_str( $length = 4 )
                        {
                             	$flag = 0;
                                if($length == 'cookie')     
                                    {   
                                        $flag = 1;      
                                        $length = 5 ;    
                                    }
                                $chars = "ABCDEFGHIJKLMNPQRSTUVWXYZ123456789";	
	                            $size = strlen( $chars );
	                            $str = '';
                                $str2 = '';

                                for( $i = 0; $i < $length; $i++ ) 
	                               {
		                                $char = $chars[ rand( 0, $size - 1 ) ];
                                        $str  .= $char;
                                        $str2 .= ' '.$char;
	                               }
                                return ( $flag ? $str.','.$str2 : $str ) ;
                        }


function create_image( $random_string)
                        {
                             $im = @imagecreate(120, 40)or die("Cannot Initialize new GD image stream");    
                             $background_color = imagecolorallocate($im, 0, 0, 0);  // black
                             $white = imagecolorallocate($im, 255, 255, 255);     
                           
                             imagestring($im, 5 , 8,  10, $random_string , $white);
                             imagepng($im,"image.png");
                             imagedestroy($im);
                         }



?>
