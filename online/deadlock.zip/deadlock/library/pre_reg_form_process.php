<?php

function pre_reg()

    {
        $dt = date("Y-m-d h:i:s");
        $flag = 0 ;
        $body = '' ;

        if(base64_decode( $_COOKIE['tk13_verify']) == $_POST['captcha'] )
            {   $flag = 1 ;   }
        else
            {   return 'Invalid Captcha. Reload the page and try again.';   }

        //validating email address
        if (filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL))       
        	  {  
                $query = 'select tk13_id,username from user_profiles where email = \''.trim($_POST['email']).'\'';
                $result = mysql_query($query);
                $row = mysql_fetch_row($result);

                if(mysql_num_rows($result) > 0 ) 
                  {   $flag = 0 ; 
                      $body = ' * This email has already been registered with the username '.$row[1].'.'.PHP_EOL ;
                  }
            } 
        else        
            { 
        	      $body = ' * Invalid email '.PHP_EOL ; 
        	      $flag = 0 ; 
        	  }
        
        //validating name and username    
        if($flag == 1)  
             {   

                 if ( strlen(trim($_POST['name'])) > 2 && strlen(trim($_POST['username'])) > 2)     
                      {   $flag = 1 ;   } 
                 else  
                      { 
                 	        $body = $body .' * Your name and username should have atleast 3 letters.'.PHP_EOL ; 
                 	        $flag = 0 ;
                      }    
                  $query = 'select tk13_id from user_profiles where username=\''.trim( $_POST['username']).'\'';
                  $result1 = mysql_query($query) ;
                  check($result1);
                  if( mysql_num_rows($result) > 0 )
                      { 
                        $flag = 0 ; 
                        $body = $body.' * The username you specified has already been taken by smart guys.'.PHP_EOL;
                      }   
             }
        
        //validating password,checking the both
        if( !($_POST['pass1'] == $_POST['pass2']) )     
             {  $flag = 0 ;   }

        //entering to users_profile table 
        if( $flag == 1 )
            {   
              $verify = random_str(5) ;            
              // inserting the user details to database 
              $result = mysql_query('INSERT INTO user_profiles ( username, password, name, email, email_verify ) 
                     VALUES (\''.trim($_POST['username']).'\',\''.base64_encode($_POST['pass1'].'ynos1234').'\',
                      \''.trim($_POST['name']).'\',\''.$_POST['email'].'\',\''.$verify.'\');');
              check($result);
                          
              //sending confirmation mail to the user
              $to = $_POST['email'];
              $subject = "Bodhi 2013 User Account Verification";
              $message = 'Dear '.$_POST['name'].','.PHP_EOL.PHP_EOL.'You have registered for Bodhi 2k13 Online Treasure Hunt of Viswajyothi College Of Engineering and Technology.'
              .PHP_EOL.'To continue with your registration , please verify your email by clicking the link given below :'.
              PHP_EOL.PHP_EOL.'http://www.bodhiofficial.in/online/reg.php?q=verify_email&email='.$_POST['email'].'&username='.$_POST['username'].'&str='.
              $verify.PHP_EOL.'(If clicking on the link dosen\'t work, please copy paste the link in any browser and press enter.)'.
              PHP_EOL.PHP_EOL.'Thank you.'.PHP_EOL.'Bodhi 2013 Team.'.PHP_EOL.PHP_EOL.
              'For more details visit www.bodhiofficial.in or drop a mail to webmaster@bodhiofficial.in.';

              $from = "admin@bodhiofficial.in";
              $headers = "From:" . $from;
              mail($to,$subject,$message,$headers);

              $body ='Please verify your email to continue with the registration. Check your spam folder also.';
           }   

        else 
           {  return $body.PHP_EOL.'You have not been registered.' ;    }

        return $body;
     } 
	
?>