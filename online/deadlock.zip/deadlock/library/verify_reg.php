<?php

function email_verify_reg()
		{
			echo 'machan';

			$link = connect();
			$result = mysql_query('select email_verify from user_profiles where email = \''.$_GET['email'].'\'');
			$row = mysql_fetch_row ( $result ) ;

			$body = '';
			if( $row[0] == 'VERIFIED')
				{
					$body = 'You have already verified your email.';
				}
			elseif( $row[0] == $_GET['str'])
				{  
					$body =  '
					<form method="post" action="index.php?q=register">
					Welcome '.$_GET['username'].',
					<input type="hidden" name="email" value="'.$_GET['email'].'" maxlength="100" /> <br/>
					<input type="hidden" name="verify" value="'.$_GET['str'].'" />
					<input type="hidden" name="username" value="'.$_GET['username'].'" />

					<br/> Student  :  <select name="student"><option>Yes</option><option>No</option></select> <br/>
					<br/> Phone  :   <input type="text" name="phone" maxlength="13"> <br/>
					<br/> College   :   <input type="text" name="college" maxlength="90"> <br/>
					<br/>  Course :   <select name="course"> <option> B.Tech </option> <option> M.Tech </option><option> Others </option></select> <br/>
					<br/>  DOB  :	<input type="text" name="day" maxlength="2">
									<input type="text" name="month" maxlength="2">
									<input type="text" name="year" maxlength="4"> <br/>
					</select> <br/>
					<br/> <input type="submit" value="Register Me" /> <br/>
					</form>	' ;
				}	 

			else
			 	{	
			 		$body = '
			 		<meta http-equiv="refresh" content="10;url=http://www.bodhiofficial.in/">'.PHP_EOL.'
 					<div class="error_msg">
 					Your verification key is not correct. <br/> If you believe this happened due to our fault please contact 
 					us at webmaster@bodhiofficial.in.You are being redirected to our website 
 					<a href="http://www.bodhiofficial.in">bodhiofficial.in .</a> </div>' ;		
 				}
 			echo $body;
 			exit;	
 		}		

?>




