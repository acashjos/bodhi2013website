<?php

function login()
         {
             $conn = connect();

             if ( $_POST['pass'] == 'machandakuttadl' && $_POST['user'] == 'dladmine')     
                          {  
                             setcookie('deadlock_admin' , $_POST['user'].'+'.'HF4SKFSIB7EEJBFJ' , time() + 3600 ) ;
                             return 1 ;
                          }   

             else         { return 0 ; }  


         }

function validate()
         {
             $conn = connect();
             $user = explode('+', $_COOKIE['deadlock_admin'] ) ;
              
             if ( $user[1] == 'HF4SKFSIB7EEJBFJ')       { return 1 ; }
             else                             { return 0 ; }   

         }

function logout()
        {
             setcookie('deadlock_admin' , $_COOKIE['deadlock_admin'] , time() - 500 ) ;
             unset($_COOKIE['deadlock_admin']);                              
        }

function random_str( $length = 5 )
        {
                $flag = 0;
                if($length == 'cookie')     
                    {   
                        $flag = 1;      
                        $length = 5 ;    
                    }
                $chars = "ABCDEFGHIJKLMNPQRSTUVWXYZ";  
                $size = strlen( $chars );
                $str = '';
                $str2 = '';

                for( $i = 0; $i < $length; $i++ ) 
                   {
                        $char = $chars[ rand( 0, $size - 1 ) ];
                        $str  .= $char;
                        $str2 .= ' '.$char;
                   }
                return ( $flag ? $str.','.$str2 : $str ) ;
        }        

?>
