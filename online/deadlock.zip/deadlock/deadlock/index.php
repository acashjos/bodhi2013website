<?php

//including the database authentication functions and variables
include_once('./library/db_common.php');

//sanitizing all the get and post variables so that it can be directly inserted into mysql database
  array_walk_recursive($_POST, 'sanitizeVariables'); 
  array_walk_recursive($_GET, 'sanitizeVariables'); 

//connecting to database
$link = connect();

$_POST['error'] = 0 ;

include_once('./library/login.php');
include_once('./library/general.php');

$query = 'update deadlock_counter set total_hits = total_hits+1';
$result = mysql_query($query);
check($result);

if ( isset($_COOKIE['deadlock_user'] ) && validate() ) 
          
        { 
            $user = explode('+', $_COOKIE['deadlock_user']);
            $page = file_get_contents('./index.html');
            if(isset($_GET['q']))
                {   
                    if($_GET['q'] == 'logout')      
                        {   
                            logout(); 
                            echo file_get_contents("./login.html") ; 
                            exit ; 
                        }

                    //process requests for leaderboard page    
                    elseif ( $_GET['q'] == 'leaderboard') 
                        {
                            $page = str_replace('{submit}', '', $page);
                            include_once('./library/leaderboard.php');
                            $page = leaderboard( $page );   
                        }

                    elseif ( $_GET['q'] == 'rules') 
                        {
                            $page = str_replace('{submit}', '', $page);
                            include_once('./library/rules.php');
                            $page = rules( $page );   
                        } 

                    elseif ( $_GET['q'] == 'submit' )    
                        {
                            include_once('./library/default.php');
                            include_once('./library/submit.php');
                            $page = submit_level( $page, $user[0]);   
                        }

                    else
                        {
                            include_once('./library/default.php');
                            $page = str_replace('{image_replace}', image_v(), $page);
                            $page = str_replace('{submit}', submit_form(), $page);
                            $page = defaultt( $page, $user[0]);
                        }       
                }
            else
                {
                    include_once('./library/default.php');
                    $page = str_replace('{image_replace}', image_v(), $page);
                    $page = str_replace('{submit}', submit_form(), $page);
                    $page = defaultt( $page, $user[0]);
                }    
            $page = str_replace('{user}', $user[0], $page );
            $page = str_replace('{refresh_time}', '', $page );
            echo $page;
        }

elseif ( isset ( $_POST ['login'] ) && $_POST['login'] == 1 )   

        {
            $body = login();
            if( $body=='login' ) //if its a valid username and password then the cookie and show him admin panel
                {       
                    echo 'You will be redirected shortly.. Else please refresh the page.
                            <meta http-equiv="refresh" content="0">' ;
                }
          
            //in case the username and password is wrong,show him the login page itself    
            else
                {  echo str_replace('{message}', $body, file_get_contents("./login.html")) ;     }            
        }       

//in case an un authorised personal gets the page, show him the login page
else

        {    echo str_replace('{message}', '', file_get_contents("./login.html"));         }           

?>