<?php


function random_str( $length = 5 )
        {
                $flag = 0;
                if($length == 'captcha')     
                    {   
                        $flag = 1;      
                        $length = 2 ;    
                    }
                $chars = "ABCDEFGHIJKLMNPQRSTUVWXYZ";  
                $size = strlen( $chars );
                $str = '';
                $str2 = '';

                for( $i = 0; $i < $length; $i++ ) 
                   {
                        $char = $chars[ rand( 0, $size - 1 ) ];
                        $str  .= $char;
                        $str2 .= ' '.$char;
                   }
                return ( $flag ? $str.','.$str2 : $str ) ;
        }

function login()
         {
             $conn = connect();

             $query = 'select tk13_id from user_profiles where username=\''.$_POST['user'].'\'';
             $result = mysql_query($query);
             check($result);
    
             if ( mysql_num_rows($result) > 0 )     
                  {  
    
                     $query = 'select tk13_id from user_profiles where username=\''.$_POST['user'].'\' and password=\''.base64_encode($_POST['password'].'ynos1234').'\'';
                     $result = mysql_query($query);
                     check($result);

                     if ( mysql_num_rows($result) > 0 )     
                          {  
                             $query = 'select tk13_id from user_profiles where username=\''.$_POST['user'].'\' and 
                             password=\''.base64_encode($_POST['password'].'ynos1234').'\' and email_verify=\'VERIFIED\'';
                             $result = mysql_query($query);
                             check($result);    

                             if(mysql_num_rows($result) > 0 )
                                {   
                                     $chumma = random_str(6);
                                     setcookie('deadlock_user' , $_POST['user'].'+'.$chumma , time() + 3600*5 ) ;

                                     #checking whether the user logins for the first time
                                     $query = 'select id from deadlock_profile where username=\''.$_POST['user'].'\'';
                                     $result = mysql_query($query);
                                     check($result);

                                     if(mysql_num_rows($result) == 0 )
                                         {
                                            #inserting into deadlock profile
                                            $query = 'insert into deadlock_profile(username,current_level,cookie_key,attempts) values (\''.$_POST['user'].'\'
                                                ,1,\''.$chumma.'\',0)';
                                            check(mysql_query($query));

                                            #updating number of deadlock users
                                            $query = 'update deadlock_counter set total_users = total_users +1';
                                            check(mysql_query($query));
                                            
                                            $query = 'update deadlock_levels set people_count = people_count+1 where id=1';
                                            check(mysql_query($query));
                                         }
                                     else
                                         {
                                            $query = 'update deadlock_profile set cookie_key = \''.$chumma.'\' where username=\''.$_POST['user'].'\'';
                                            $result = mysql_query($query);
                                            check($result);
                                         }    
                                     return 'login' ;
                                }
                             else
                                {
                                    return 'You have registered but haven\'t verified your email yet. Please verify your email to proceed. Check your 
                                    spam box also for the confirmation mail.';
                                }        
                        }
                    else
                        {
                            return 'Your password is incorrect.';
                        }            
                  }   

             else         { return 'You haven\'t registred yet. Please register @ <a href="http://techkshetra.in/">techkshetra.in</a>'; }  

         }

function validate()
         {
             $conn = connect();
             if( substr_count($_COOKIE['deadlock_user'], '+') > 0 )
                    {   $user = explode('+', $_COOKIE['deadlock_user'] ) ;    }
             else
                    {   $user = array($_COOKIE['deadlock_user'],' ');    }   
             
             $query = 'select csrs_key,image_captcha,cookie_key from deadlock_profile where username=\''.$user[0].'\'';
             $result = mysql_query($query);
             check($query);

             if ( mysql_num_rows($result) > 0)       
                        { 
                            $row = mysql_fetch_row($result);
                            if(isset($_POST['captcha']))
                                {
                                    if($row[2] == $user[1])
                                        {
                                            $c = md5( base64_encode($_POST['captcha'])) ;
                                            $cap = $c[0].$c[1].$c[2];
                                            if( $cap == $row[1] )
                                                {
                                                    if($_POST['csrs'] == $row[0])
                                                        {   return 1;  }
                                                    else
                                                        {   return 0 ; }
                                                }
                                            else
                                                {   
                                                    $_POST['error'] = 1;
                                                    return 1 ; 
                                                } 
                                        }
                                    else
                                        {   return 0 ;  }               
                                }
                            else
                                {   
                                    if($row[2] == $user[1])
                                        {
                                            return 1;   
                                        }
                                    else 
                                        {
                                            return 0 ;
                                        }     
                                }    
                        }
             else       { return 0 ; }   

         }

function logout()
        {
             setcookie('deadlock_user' , $_COOKIE['deadlock_user'] , time() - 500 ) ;
             unset($_COOKIE['deadlock_user']); 
             echo str_replace('{message}', 'You have been logged out.', file_get_contents("./login.html"));
             exit;                             
        }
        

?>
