<!DOCTYPE html>
<html>
<head>
    <title>Complete your registration</title>
    <link rel="stylesheet" type="text/css" href="css/regCompStyles.css" />
</head>
<body>
    <form action="index.php?q=register" method="POST" class="register">
        <h1>Welcome <?php echo $_GET['username']; ?>.<h1><h2>Please complete your registration.</h2>
        <p>
			<input type="hidden" name="email" value="<?php echo $_GET['email']; ?>" maxlength="100" />
            <br />
            <input type="hidden" name="verify" value="<?php echo $_GET['str']; ?>" />
            <input type="hidden" name="username" value="<?php echo $_GET['username']; ?>" />
            <label>College</label>
            <input type="text" name="college" maxlength="90" placeholder="College" />
            <br />
            <br />
            <label>Phone</label>
            <input type="text" name="phone" maxlength="13" placeholder="Phone" />
            <br />
            <br />
            <label>Course</label><select name="course">
                <option>B.Tech</option>
                <option>M.Tech</option>
                <option>Others</option>
            </select><br />
        </p>
        <p>
            <label>Date of Birth</label>
            <input class="dateField" type="text" name="day" value="" placeholder="Day" />
            <input class="dateField" type="text" name="month" value="" placeholder="Month" />
            <input class="dateField" type="text" name="year" value="" placeholder="Year" />
            <input type="submit" class="button" value="Register" style="width: 150px" />
    </form>
</body>
</html>
